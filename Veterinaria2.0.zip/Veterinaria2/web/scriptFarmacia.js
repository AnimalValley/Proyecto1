var xhr;
function crearObjeto() {
    if (window.ActiveXObject) {
//                alert("Navegador no soporta AJAX");
        xhr = new ActiveXObject("Microsoft.XMLHttp");
    } else if ((window.XMLHttpRequest) || (typeof XMLHttpRequest) != undefined) {
//                alert("Navegador no soporta AJAX");
        xhr = new XMLHttpRequest();
    } else {
        alert("Navegador no soporta AJAX");
        return;
    }

}

var divInicial = "inicio";
function DinamicoDiv(divActual) {
    alert(divActual)
    document.getElementById(divActual).style.display = 'block';
    //document.getElementById(a).style.visibility='hidden';
    if (divInicial != divActual) {
        document.getElementById(divInicial).style.display = 'none';
    }
    divInicial = divActual;
}

function buscarOpcion() {
    crearObjeto();
    enviapeticion2();
}

////////////////////////////////////////CONSULTAR PRODUCTO//////////////////////////////////

function consultarProducto() {
    crearObjeto();
    enviaProducto();
}

function enviaProducto() {
    xhr.open("GET", "ConsultarProducto", true);
    //alert("asdfghj");
    xhr.onreadystatechange = verificaDetalleConsulP;
    xhr.send(null);
}

function verificaDetalleConsulP() {
    if (xhr.readyState == 4) {
        document.getElementById("Produ").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

function ConsultarP() {
    var nameP = document.getElementById("nombre").value;
    xhr.open("POST", "ConsultarProducto", true);
    //alert("asdfghj");
    xhr.onreadystatechange = verificaDetallesP;
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send("&nombre=" + nameP);

}

function verificaDetallesP() {
    if (xhr.readyState == 4) {
        document.getElementById("consultaP").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

/////////////////////////////////////REGISTRAR PRODUCTO///////////////////////////////////////////

function RegistrarProducto() {
    crearObjeto();
    xhr.open("GET", "RegistrarProducto", true);
    xhr.onreadystatechange = verificaDetalle;
    xhr.send(null);
}

function verificaDetalle() {
    if (xhr.readyState == 4) {
        document.getElementById("Produ").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

function RegistrarPr() {
    crearObjeto();
    var nom = document.getElementById("nombre").value;
    var cos = document.getElementById("costo").value;
    var can = document.getElementById("cantidad").value;
    var pro = document.getElementById("promocion").value;
    var des = document.getElementById("descripcion").value;
    
    //alert(nom+cos+can+pro+des);

    xhr.open("POST", "RegistrarProducto", true);
    xhr.onreadystatechange = verificaDetalleRP;
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send("nombre=" + nom + "&costo=" + cos + "&cantidad=" + can + "&promocion=" + pro + "&descripcion=" + des);
}

function verificaDetalleRP() {
    if (xhr.readyState == 4) {
        document.getElementById("registrarP").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

/////////////////////////////////////ACTUALIZAR PRODUCTO///////////////////////////////////////////

function ActualizarProducto() {
    crearObjeto();
    enviarProducto();
}

function enviarProducto() {
    xhr.open("GET", "ActualizarProducto", true);
    //alert("asdfghj");
    xhr.onreadystatechange = verificaDetalleConsulPr;
    xhr.send(null);
}

function verificaDetalleConsulPr() {
    if (xhr.readyState == 4) {
        document.getElementById("Produ").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

function ConsultarPro() {
    var nameP = document.getElementById("nombre").value;
    xhr.open("POST", "ActualizarProducto", true);
    //alert("asdfghj");
    xhr.onreadystatechange = verificaDetallesPr;
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send("&nombre=" + nameP);
}

function verificaDetallesPr() {
    if (xhr.readyState == 4) {
        document.getElementById("consultarProducto").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

function otro() {
    crearObjeto();
    actua();
}

function actua(){
    var id_pro = document.getElementById("id_producto").value;
    var nom = document.getElementById("nombre").value;
    var cost = document.getElementById("costo").value;
    var cant = document.getElementById("cantidad").value;
    var prom = document.getElementById("promocion").value;
    var des = document.getElementById("descripcion").value;

    xhr.open("GET", "ActPro?id_producto="+id_pro+"&nombre="+nom+" &costo="
    +cost+"&cantidad="+cant+"&promocion="+prom+"&descripcion="+des, true);
    xhr.onreadystatechange = verificaDetalle6;
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send(null);
}

function verificaDetalle6() {
    if (xhr.readyState == 4) {
        document.getElementById("respuestaAct").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

//////////////////////////////////////CONSULTAR MASCOTA//////////////////////////////////////////////////

function ConsultarMascota() {
    crearObjeto();
    enviaMascota();
}

function enviaMascota() {
    xhr.open("GET", "ConsultarMascota", true);
    //alert("asdfghj");
    xhr.onreadystatechange = verificaDetalleConsulM;
    xhr.send(null);
}

function verificaDetalleConsulM() {
    if (xhr.readyState == 4) {
        document.getElementById("Mascota").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

function ConsultarM() {
    var nameM = document.getElementById("nombre").value;
    xhr.open("POST", "ConsultarMascota", true);
    //alert("asdfghj");
    xhr.onreadystatechange = verificaDetallesM;
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send("&nombre=" + nameM);

}

function verificaDetallesM() {
    if (xhr.readyState == 4) {
        document.getElementById("consultaM").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

//////////////////////////REGISTRAR MASCOTA//////////////////////////////////////

function RegistrarMascota() {
    crearObjeto();
    xhr.open("GET", "RegistrarMascota", true);
    xhr.onreadystatechange = verificaDetalleMas;
    xhr.send(null);
}

function verificaDetalleMas() {
    if (xhr.readyState == 4) {
        document.getElementById("Mascota").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

function RegistrarMas() {
    crearObjeto();
    var nom = document.getElementById("nombre").value;
    var tip = document.getElementById("tipo").value;
    var raz = document.getElementById("raza").value;
    var eda = document.getElementById("edad").value;
    var fec = document.getElementById("fecha_nac").value;
    var pes = document.getElementById("peso").value;
    var des = document.getElementById("descripcion").value;
    var gen = document.getElementById("genero").value;
    var sal = document.getElementById("salud").value;
    
    //alert(nom+cos+can+pro+des);

    xhr.open("POST", "RegistrarMascota", true);
    xhr.onreadystatechange = verificaDetalleRM;
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send("nombre=" + nom + "&tipo=" + tip + "&raza=" + raz + "&edad=" + eda + "&fecha_nac=" + fec + 
            "&peso=" + pes + "&descripcion=" + des + "&genero=" + gen + "&salud=" + sal);
}

function verificaDetalleRM() {
    if (xhr.readyState == 4) {
        document.getElementById("registrarM").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

//////////////////////////////////////CONSULTAR MEDICAMENTO//////////////////////////////////////////////////

function ConsultarMedica() {
    crearObjeto();
    enviaMedica();
}

function enviaMedica() {
    xhr.open("GET", "ConsultarMedicamento", true);
    //alert("asdfghj");
    xhr.onreadystatechange = verificaDetalleConsulMed;
    xhr.send(null);
}

function verificaDetalleConsulMed() {
    if (xhr.readyState == 4) {
        document.getElementById("Medica").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

function ConsultarMed() {
    var nameMed = document.getElementById("nombre").value;
    xhr.open("POST", "ConsultarMedicamento", true);
    //alert("asdfghj");
    xhr.onreadystatechange = verificaDetallesMed;
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send("&nombre=" + nameMed);

}

function verificaDetallesMed() {
    if (xhr.readyState == 4) {
        document.getElementById("consultaMed").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

//////////////////////////REGISTRAR MEDICAMENTO//////////////////////////////////////

function RegistrarMedica() {
    crearObjeto();
    xhr.open("GET", "RegistrarMedicamento", true);
    xhr.onreadystatechange = verificaDetalleMed;
    xhr.send(null);
}

function verificaDetalleMed() {
    if (xhr.readyState == 4) {
        document.getElementById("Medica").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}

function RegistrarMed() {
    crearObjeto();
    var nom = document.getElementById("nombre").value;
    var suA = document.getElementById("sustActiva").value;
    var des = document.getElementById("descripcion").value;
    var cos = document.getElementById("costo").value;
    var can = document.getElementById("cantidad").value;
    
    //alert(nom+cos+can+pro+des);

    xhr.open("POST", "RegistrarMedicamento", true);
    xhr.onreadystatechange = verificaDetalleRM;
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send("nombre=" + nom + "&sustActiva=" + suA + "&descripcion=" + des + "&costo=" + cos + "&cantidad=" + can);
}

function verificaDetalleRM() {
    if (xhr.readyState == 4) {
        document.getElementById("registrarMed").innerHTML = "<em>" + xhr.responseText + "</em>";
    }
}