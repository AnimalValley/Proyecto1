/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var xhr;
function crearObjeto() {
    if (window.ActiveXObject) {
//                alert("Navegador no soporta AJAX");
        xhr = new ActiveXObject("Microsoft.XMLHttp");
    } else if ((window.XMLHttpRequest) || (typeof XMLHttpRequest) != undefined) {
//                alert("Navegador no soporta AJAX");
        xhr = new XMLHttpRequest();
    } else {
        alert("Navegador no soporta AJAX");
        return;
    }

}

var divInicial = "inicio";
function DinamicoDiv(divActual) {
    alert(divActual)
    document.getElementById(divActual).style.display = 'block';
    //document.getElementById(a).style.visibility='hidden';
    if (divInicial != divActual) {
        document.getElementById(divInicial).style.display = 'none';
    }
    divInicial = divActual;
}

function buscarOpcion() {
    crearObjeto();
    enviapeticion2();
}


