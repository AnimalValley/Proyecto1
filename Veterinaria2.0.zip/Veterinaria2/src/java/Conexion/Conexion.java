package Conexion;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion {

    public Connection conexión = null;
    public Statement sentenciaSQL = null;

    public void Conectar() {
        try {
            String controlador = "com.mysql.jdbc.Driver";
            Class.forName(controlador).newInstance();
            conexión = DriverManager.getConnection("jdbc:mysql://localhost:3306/Veterinaria", "root", "");
            sentenciaSQL = getConexión().createStatement();
        } catch (ClassNotFoundException ex) {
            System.out.println("No se pudo cargar el controlador: " + ex.getMessage());
        } catch (InstantiationException ex) {
            System.out.println("Objeto no creado. " + ex.getMessage());
        } catch (IllegalAccessException ex) {
            System.out.println("Acceso Ilegal. " + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("Excepción SQL: " + ex.getMessage());
        }
    }

    public void cerrar() {
        try {
            if (getSentenciaSQL() != null) {
                getSentenciaSQL().close();
            }
            if (getConexión() != null) {
                getConexión().close();
            }
        } catch (SQLException ignorada) {
            System.out.println("CONEXION IGNORADA ");
        }
    }

    public Connection getConexión() {
        return conexión;
    }

    public Statement getSentenciaSQL() {
        return sentenciaSQL;
    }
}
