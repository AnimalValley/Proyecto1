package Cliente;

import Conexion.Conexion;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ConsultarProducto extends HttpServlet {

    ResultSet cdr = null;
    Statement sentenciaSQL = null;
    Conexion conecta = new Conexion();

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        conecta.Conectar();
        sentenciaSQL = conecta.getSentenciaSQL();
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ConsultarProducto</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ConsultarProducto at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        PrintWriter out = response.getWriter();
        try {
            String paciente = "Select * from Producto";
            cdr = sentenciaSQL.executeQuery(paciente);

            out.println("<center><h1>Consultar Producto</h1>\n");
            out.println("Nombre:<select id=\"nombre\" onchange='ConsultarP();'><option>Selecciona...</option>");
            while (cdr.next()) {
                out.println("<option>" + cdr.getString(2) + "</option>");
            }
            out.println("</select>");
            out.println("<br><br>");
            out.println("<center><div id=\"consultaP\"></div></center>");
        } catch (SQLException e) {
            out.println("Exception SQL: " + e.getMessage());
        } catch (NullPointerException e) {
            out.println("Apuntando SQL: " + e.getMessage());
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        PrintWriter out = response.getWriter();
        String nombreP = request.getParameter("nombre");
        try {
            String consultHi = "select * from Producto where nombre='"
                    + nombreP + "'";
            cdr = sentenciaSQL.executeQuery(consultHi);

            out.println("<table width=100% border=1>");
            out.println("<tr>");
            out.println("<th>Nombre</th><th>Descripci&oacute;n</th><th>Costo</th><th>Cantidad</th>"
                    + "<th>Promoci&oacute;n</th>");
            out.println("</tr>");

            while (cdr.next()) {
                out.println("<tr>");
                out.println("<td width= 10%>" + cdr.getString("nombre") + "</td>");
                out.println("<td width= 30%>" + cdr.getString("descripcion") + "</td>");
                out.println("<td width= 20%>" + cdr.getString("costo") + "</td>");
                out.println("<td width= 20%>" + cdr.getString("cantidad") + "</td>");
                out.println("<td width= 20%>" + cdr.getString("promocion") + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");
        } catch (SQLException e) {
            out.println("Exception SQL: " + e.getMessage());
        } catch (NullPointerException e) {
            out.println("Apuntando SQL: " + e.getMessage());
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
