package Cliente;

import Conexion.Conexion;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegistrarMascota extends HttpServlet {

    ResultSet cdr = null;
    Statement sentenciaSQL = null;
    Conexion conecta = new Conexion();

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        conecta.Conectar();
        sentenciaSQL = conecta.getSentenciaSQL();
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegistrarMascota</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RegistrarMascota at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        PrintWriter out = response.getWriter();
        out.print("<center>");
        out.print("<h1>REGISTRO DE MASCOTAS</h1>");
        out.print("<p>Nombre:</p>");
        out.println("<input type=\"text\" id=\"nombre\">");
        out.print("<p>Tipo:</p>");
        out.println("<input type=\"text\" id=\"tipo\">");
        out.print("<p>Raza:</p>");
        out.println("<input type=\"text\" id=\"raza\">");
        out.print("<p>Edad:</p>");
        out.println("<input type=\"number\" id=\"edad\">");
        out.print("<p>Fechas Nacimiento:</p>");
        out.println("<input type=\"date\" id=\"fecha_nac\">");
        out.print("<p>Peso:</p>");
        out.println("<input type=\"text\" id=\"peso\" placeholder='Kg'>");
        out.print("<p>Descripci&oacute;n:</p>");
        out.println("<input type=\"text\" id=\"descripcion\">");
        out.print("<p>Genero:</p>");
        out.println("<select id=\"genero\"><option>Selecciona...</option><option>M</option>"
                + "<option>H</option></select>");
        out.print("<p>Salud:</p>");
        out.println("<select id=\"salud\"><option>Selecciona...</option><option>Estable</option>"
                + "<option>Critico</option></select>");
        out.print("<br><br><button onclick='RegistrarMas();'>REGISTRAR</button><br><br>");
        out.print("<div id=\"registrarM\"></div>");
        out.print("</center>");
        out.close();
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        PrintWriter out = response.getWriter();
        try {
            String nom = request.getParameter("nombre");
            String tipo = request.getParameter("tipo");
            String raza = request.getParameter("raza");
            int edad = Integer.parseInt(request.getParameter("edad"));
            String fecha = request.getParameter("fecha_nac");
            int peso = Integer.parseInt(request.getParameter("peso"));
            String des = request.getParameter("descripcion");
            String gen = request.getParameter("genero");
            String sal = request.getParameter("salud");
            String strComando = "insert into Mascota values(null,'" + nom + "','" + tipo + "','" + raza + "'," + edad + ",'" + fecha + "','"
                    + peso + "','" + des + "','" + gen + "','" + sal + "');";
            sentenciaSQL.executeUpdate(strComando);
            out.println("<div>La Mascota Se registrd&oacute; Correctamente</div>");
        } catch (SQLException ex) {
            Logger.getLogger(RegistrarProducto.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            out.close();
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
